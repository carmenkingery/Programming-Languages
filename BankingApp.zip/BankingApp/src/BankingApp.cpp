//============================================================================
// Name        : BankingApp.cpp
// Author      : Carmen Kingery
// Version     : Beta
// Copyright   : No copy rights
// Description : Receives banking information as input,
//				 calculates interest earned and end balance,
//				 and prints results to the screen.
//============================================================================

#include <iostream>
#include <iomanip>
#include <stdlib.h>
#include <conio.h>
using namespace std;

// function declaration
void ResultsDisplay();
void CalculateBalance();

// universal variables
double initialInvestment;
double monthlyDeposit;
double annualInterestRate;
int numOfYears;
char keyPressed = 'A';

int main(){
	while (keyPressed != 'e'){
		// Receive input data
		cout << setw(34) << setfill('*') << "" << endl;
		cout << setw(11) << setfill('*') << "";
		cout << " Data Input ";
		cout << setw(11) << setfill('*') << "" << endl;

		// Get initial investment amount
		cout << "Initial Investment Amount: ";
		cin >> initialInvestment;

		// Get monthly deposit
		cout << "Monthly Deposit: ";
		cin >> monthlyDeposit;

		// Get annual interest
		cout << "Annual Interest: ";
		cin >> annualInterestRate;

		// Get number of years
		cout << "Number of years: ";
		cin >> numOfYears;

		// Ask to continue
		cout << "Enter any key to continue . . ." << endl;
		cout << endl;
		cin >> keyPressed;
		system("CLS");

		// Calculate balance and interest earned per month
		// display results per year without monthly deposits
		cout << "  Balance and Interest Without Additional Monthly Deposits" << endl;
		double temp = monthlyDeposit;
		monthlyDeposit = 0;
		ResultsDisplay();
		CalculateBalance();
		monthlyDeposit = temp;
		cout << endl;

		// display results per year with monthly deposits
		cout << "  Balance and Interest With Additional Monthly Deposits" << endl;
		ResultsDisplay();
		CalculateBalance();

		// Ask to continue to try different inputs
		cout << endl;
		cout << "Enter any key to continue or e to exit" << endl;
		cin >> keyPressed;

	}
	return 0;
}

// Definition of ResultsDisplay, preps screen for outputting
// the number results
void ResultsDisplay(){
	cout << setw(60) << setfill('-') << "" << endl;
	cout << setw(60) << setfill('-') << "" << endl;
	cout << " Year" << "\t" << "  Year End Balance" << "\t"
			<< "Year End Earned Interest" << endl;
	cout << setw(60) << setfill('-') << "" << endl;
}

// Definition of CalculateBalance, calculates the end balance every year
// and total interest earned each year and prints to the screen
void CalculateBalance(){
	double endBalance;
	double totalInterest;
	int months = 12;
	double interest;
	double balanceBeforeInterest;

	for (int i=1; i <= numOfYears; ++i){
		totalInterest = 0;
		for (int j=1; j <= months; ++j){
			balanceBeforeInterest = initialInvestment + monthlyDeposit;
			interest = balanceBeforeInterest * ((annualInterestRate/100)/12);
			totalInterest += interest;
			endBalance = balanceBeforeInterest + interest;
			initialInvestment = endBalance;
		}
		cout << setw(4) << setfill(' ') << right << i;
		cout << fixed << setprecision(2) << setw(22)
				<< setfill(' ') << right << endBalance;
		cout << fixed << setprecision(2) << setw(30)
				<< setfill(' ') << right << totalInterest << endl;
	}
}
